﻿namespace DatabaseCourceWork.DesktopApplication.Database.Models.Enums
{
    internal enum CulturalEventStatus 
    {
        Scheduled, 
        Cancelled,
        Completed
    }
}
