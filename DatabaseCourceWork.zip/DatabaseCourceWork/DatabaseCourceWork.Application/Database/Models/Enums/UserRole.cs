﻿namespace DatabaseCourceWork.DesktopApplication.Database.Models.Enums
{
    internal enum UserRole
    {
        Artist,
        Organizer,
        Visitor
    }
}
